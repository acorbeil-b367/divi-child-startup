<p class="howto frm_clear">
	<?php esc_html_e( 'Note: This field will not show in the form, but will link the user id to it as long as the user is logged in at the time of form submission.', 'formidable' ) ?>
</p>

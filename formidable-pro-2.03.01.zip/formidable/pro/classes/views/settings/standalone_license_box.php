<form action="" method="post">
	<?php $edd_update->pro_cred_form(); ?>
</form>